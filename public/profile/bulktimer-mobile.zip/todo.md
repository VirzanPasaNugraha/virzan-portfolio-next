# Project TODO

- [x] Menginventarisasi jadwal latihan, layar, dan logika timer dari proyek Lovable.
- [x] Menyesuaikan desain mobile BulkTimer dan struktur navigasi Expo.
- [x] Membuat model jadwal latihan dan penyimpanan riwayat lokal.
- [x] Membangun Beranda dan detail hari latihan.
- [x] Membangun sesi timer aktif dengan kontrol mulai, jeda, lanjut, dan selesai.
- [x] Membangun Riwayat, Tips, Panduan, Kebijakan, dan Persyaratan.
- [x] Membuat logo BulkTimer dan menerapkan branding aplikasi.
- [x] Memvalidasi tipe, lint, dan alur inti aplikasi.
- [ ] Menghasilkan paket Android yang siap diinstal.
- [ ] Menyiapkan berkas unduhan dan panduan pemasangan melalui tautan langsung.
- [x] Membandingkan tata letak, warna, dan komponen versi Android dengan proyek Lovable asli.
- [x] Memperbaiki safe area, tinggi tab bar, dan ruang bawah agar tidak tertutup navigasi Android.
- [x] Menyesuaikan skala, warna, radius, dan jarak layar mobile agar sedekat mungkin dengan tampilan Lovable.
- [x] Memvalidasi tampilan pada viewport ponsel dan menyimpan checkpoint perbaikan responsif.

- [x] Menambahkan nama pengembang Virzan Pasa Nugraha pada halaman Panduan dan informasi aplikasi.
- [x] Menyiapkan contoh animasi atau video gerakan untuk seluruh gerakan unik pada jadwal latihan.
- [ ] Menambahkan pemutar video atau tautan video pada kartu/detail setiap gerakan. Catatan: diganti sementara dengan animasi offline karena pembuatan video AI tidak tersedia pada paket akun saat ini.
- [x] Memvalidasi pemetaan video agar setiap nama gerakan membuka contoh yang benar.
- [x] Menjalankan validasi akhir dan menyimpan checkpoint fitur video.

- [x] Mengganti nama tampilan aplikasi menjadi VirzanWorkout pada konfigurasi dan layar utama.
- [x] Mencerahkan warna seluruh teks dan label agar terbaca jelas pada tema gelap.
- [x] Menyiapkan gambar contoh gerakan untuk setiap jenis latihan unik.
- [x] Menampilkan gambar gerakan pada kartu latihan dan saat sesi latihan dimulai.
- [x] Memvalidasi aset gambar, kontras teks, dan alur mulai latihan.

- [x] Mendiagnosis mengapa gambar contoh gerakan belum terlihat pada aplikasi.
- [x] Mengganti sumber aset gambar dengan sumber yang dapat dimuat stabil pada Android.
- [x] Menambahkan fallback tampilan jika gambar belum selesai dimuat atau gagal dimuat.
- [x] Memvalidasi gambar pada detail gerakan dan layar mulai sesi.

- [x] Memperbaiki mapping gambar agar Pull Up, Row, Squat, dan gerakan lain tidak memakai gambar Push Up.
- [x] Memastikan aset lokal spesifik setiap gerakan tersedia dan terhubung ke nama olahraga yang benar.
- [x] Mengubah ikon play serta ikon tombol utama menjadi putih dan terlihat jelas.
- [x] Mengubah teks Set Selesai, Lanjutkan Sesi, dan Mulai Sesi menjadi putih.
- [x] Menjalankan validasi akhir dan menyimpan checkpoint perbaikan.

- [x] Mendiagnosis penyebab build APK VirzanWorkout gagal dari log dan konfigurasi.
- [x] Memperbaiki error build yang ditemukan tanpa menghapus fitur aplikasi.
- [x] Menjalankan validasi proyek dan menyimpan checkpoint perbaikan build.
