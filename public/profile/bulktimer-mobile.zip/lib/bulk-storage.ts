import AsyncStorage from "@react-native-async-storage/async-storage";

export interface ActiveSession {
  dayId: string;
  date: string;
  startedAt: number;
  done: Record<string, number>;
}

export interface HistoryEntry {
  id: string;
  date: string;
  dayId: string;
  dayName: string;
  focus: string;
  kcal: number;
  status: "done" | "partial";
  completedAt: number;
}

const SESSION_KEY = "bulktimer.session.v1";
const HISTORY_KEY = "bulktimer.history.v1";

async function read<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

async function write(key: string, value: unknown) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Penyimpanan lokal dapat penuh atau sementara tidak tersedia.
  }
}

export const loadSession = () => read<ActiveSession | null>(SESSION_KEY, null);
export const saveSession = (session: ActiveSession) => write(SESSION_KEY, session);
export const clearSession = () => AsyncStorage.removeItem(SESSION_KEY);
export const loadHistory = () => read<HistoryEntry[]>(HISTORY_KEY, []);

export async function addHistory(entry: HistoryEntry) {
  const all = await loadHistory();
  const next = [entry, ...all.filter((item) => !(item.date === entry.date && item.dayId === entry.dayId))].slice(0, 120);
  await write(HISTORY_KEY, next);
}

export const clearHistory = () => AsyncStorage.removeItem(HISTORY_KEY);
