import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Card, palette } from "@/components/bulk-ui";

const privacy = [
  ["Data yang disimpan", "BulkTimer menyimpan progres sesi dan riwayat latihan hanya pada perangkat Anda melalui penyimpanan lokal."],
  ["Akun dan server", "Aplikasi tidak mewajibkan akun dan tidak mengirimkan data latihan ke server kami."],
  ["Penghapusan data", "Anda dapat menghapus seluruh riwayat dari layar Riwayat. Menghapus aplikasi juga dapat menghapus data lokal."],
  ["Izin perangkat", "Aplikasi hanya menggunakan umpan balik getar untuk interaksi tertentu. Tidak ada pelacakan iklan atau analitik pihak ketiga."],
];
const terms = [
  ["Tujuan aplikasi", "BulkTimer adalah alat bantu pengaturan latihan dan bukan pengganti nasihat medis, gizi, atau pelatih profesional."],
  ["Keamanan latihan", "Hentikan latihan bila mengalami nyeri atau ketidaknyamanan. Konsultasikan tenaga medis atau pelatih bila diperlukan."],
  ["Ketepatan informasi", "Estimasi kalori, durasi, dan jadwal disediakan sebagai panduan umum dan dapat berbeda pada setiap individu."],
  ["Penggunaan pribadi", "Aplikasi ini ditujukan untuk penggunaan pribadi. Pengguna bertanggung jawab atas cara memakai rekomendasi latihan."],
];

export default function LegalScreen() { const { document } = useLocalSearchParams<{ document: string }>(); const isPrivacy = document === "privacy"; const title = isPrivacy ? "Kebijakan Privasi" : "Persyaratan"; const intro = isPrivacy ? "Ringkasan cara BulkTimer menangani data di perangkat Anda." : "Hal penting sebelum menggunakan jadwal latihan BulkTimer."; const sections = isPrivacy ? privacy : terms; return <ScreenContainer className="flex-1" containerClassName="bg-background"><FlatList data={sections} keyExtractor={(item) => item[0]} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false} ListHeaderComponent={<View><Pressable onPress={() => router.back()} style={styles.back}><MaterialIcons name="arrow-back" size={19} color={palette.text} /><Text style={styles.backText}>Kembali</Text></Pressable><Text style={styles.title}>{title}</Text><Text style={styles.subtitle}>{intro}</Text></View>} renderItem={({ item, index }) => <Card style={[styles.card, index === 0 && styles.firstCard]}><Text style={styles.cardTitle}>{item[0]}</Text><Text style={styles.cardText}>{item[1]}</Text></Card>} ItemSeparatorComponent={() => <View style={{ height: 10 }} />} /></ScreenContainer>; }
const styles = StyleSheet.create({ list: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 26, width: "100%", maxWidth: 560, alignSelf: "center" }, back: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 5, minHeight: 38 }, backText: { color: palette.text, fontSize: 14, fontWeight: "800" }, title: { color: palette.text, fontSize: 31, fontWeight: "900", marginTop: 18 }, subtitle: { color: palette.muted, fontSize: 14, lineHeight: 20, marginTop: 6 }, card: { padding: 17 }, firstCard: { marginTop: 26 }, cardTitle: { color: palette.text, fontSize: 15, fontWeight: "900" }, cardText: { color: palette.muted, fontSize: 13, lineHeight: 20, marginTop: 6 }, });
