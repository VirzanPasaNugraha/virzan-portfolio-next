import "../global.css";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { Platform } from "react-native";
import * as NavigationBar from "expo-navigation-bar";
import { palette } from "@/components/bulk-ui";
import { ThemeProvider } from "@/lib/theme-provider";

function AndroidSystemBars() {
  useEffect(() => {
    if (Platform.OS !== "android") return;
    NavigationBar.setStyle("dark");
  }, []);
  return null;
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <AndroidSystemBars />
      <StatusBar style="light" backgroundColor="transparent" translucent />
      <Stack screenOptions={{ headerShown: false, animation: "slide_from_right", contentStyle: { backgroundColor: palette.background } }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="day/[dayId]" />
        <Stack.Screen name="exercise/[exerciseId]" />
        <Stack.Screen name="session" options={{ gestureEnabled: false }} />
        <Stack.Screen name="guide" />
        <Stack.Screen name="legal/[document]" />
      </Stack>
    </ThemeProvider>
  );
}
