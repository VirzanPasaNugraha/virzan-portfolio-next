import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { ScreenContainer } from "@/components/screen-container";
import { Card, palette, PrimaryButton, Tag } from "@/components/bulk-ui";
import { ExerciseDemo } from "@/components/exercise-demo";
import { formatClock, getDayByIndex, getTodayIndex, setsOf, todayKey, totalSetsOf, type Exercise } from "@/data/bulk";
import { addHistory, clearSession, loadSession, saveSession } from "@/lib/bulk-storage";
import { haptic } from "@/lib/haptics";

type Phase = "work" | "rest" | "duration" | "done";
const RING_SIZE = 268;
const RING_RADIUS = 118;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

export default function SessionScreen() {
  const day = getDayByIndex(getTodayIndex());
  const [ready, setReady] = useState(false);
  const [done, setDone] = useState<Record<string, number>>({});
  const [phase, setPhase] = useState<Phase>("work");
  const [remaining, setRemaining] = useState(0);
  const [total, setTotal] = useState(0);
  const [endsAt, setEndsAt] = useState<number | null>(null);
  const [timerRunning, setTimerRunning] = useState(false);

  useEffect(() => { void loadSession().then((session) => { if (session?.date === todayKey() && session.dayId === day.id) setDone(session.done); setReady(true); }); }, [day.id]);

  const currentIndex = useMemo(() => day.exercises.findIndex((exercise) => (done[exercise.id] ?? 0) < setsOf(exercise)), [day.exercises, done]);
  const current = currentIndex >= 0 ? day.exercises[currentIndex] : undefined;
  const totalSets = totalSetsOf(day);
  const doneSets = day.exercises.reduce((sum, exercise) => sum + Math.min(done[exercise.id] ?? 0, setsOf(exercise)), 0);
  const kcalDone = day.exercises.reduce((sum, exercise) => sum + ((done[exercise.id] ?? 0) >= setsOf(exercise) ? exercise.kcal : 0), 0);

  const persist = useCallback((next: Record<string, number>) => saveSession({ dayId: day.id, date: todayKey(), startedAt: Date.now(), done: next }), [day.id]);
  const completeSet = useCallback((exercise: Exercise, withRest: boolean) => {
    const next = { ...done, [exercise.id]: Math.min((done[exercise.id] ?? 0) + 1, setsOf(exercise)) };
    setDone(next); void persist(next); haptic.success();
    if (withRest && exercise.restSeconds > 0) {
      const rest = (next[exercise.id] ?? 0) >= setsOf(exercise) ? Math.max(exercise.restSeconds, 90) : exercise.restSeconds;
      setPhase("rest"); setTotal(rest); setRemaining(rest); setEndsAt(Date.now() + rest * 1000); setTimerRunning(true);
    } else { setPhase("work"); setTimerRunning(false); setEndsAt(null); }
  }, [done, persist]);

  useEffect(() => {
    if (!timerRunning || endsAt === null) return;
    const timer = setInterval(() => {
      const left = Math.max(0, (endsAt - Date.now()) / 1000);
      setRemaining(left);
      if (left <= 0) {
        clearInterval(timer); setTimerRunning(false); setEndsAt(null);
        if (phase === "rest") { setPhase("work"); haptic.light(); }
        if (phase === "duration" && current) completeSet(current, false);
      }
    }, 250);
    return () => clearInterval(timer);
  }, [completeSet, current, endsAt, phase, timerRunning]);

  const startDuration = () => { if (!current?.durationSeconds) return; haptic.light(); setPhase("duration"); setTotal(current.durationSeconds); setRemaining(current.durationSeconds); setEndsAt(Date.now() + current.durationSeconds * 1000); setTimerRunning(true); };
  const togglePause = () => { haptic.medium(); if (timerRunning) { setTimerRunning(false); setEndsAt(null); } else { setEndsAt(Date.now() + remaining * 1000); setTimerRunning(true); } };
  const addTime = (seconds: number) => { haptic.light(); setRemaining((value) => value + seconds); setTotal((value) => value + seconds); if (timerRunning) setEndsAt((value) => (value ?? Date.now()) + seconds * 1000); };
  const finish = useCallback(async (status: "done" | "partial") => { await addHistory({ id: `${todayKey()}-${day.id}`, date: todayKey(), dayId: day.id, dayName: day.dayName, focus: day.focus, kcal: kcalDone, status, completedAt: Date.now() }); await clearSession(); }, [day, kcalDone]);

  useEffect(() => { if (ready && currentIndex === -1 && phase !== "done") { setPhase("done"); void finish("done"); } }, [currentIndex, finish, phase, ready]);

  const endPartial = () => Alert.alert("Akhiri sesi?", "Progres yang sudah dicatat akan tetap tersimpan di riwayat.", [{ text: "Lanjutkan", style: "cancel" }, { text: "Akhiri", style: "destructive", onPress: () => { void finish("partial").then(() => router.replace("/")); } }]);
  if (!ready) return <ScreenContainer className="flex-1 items-center justify-center"><Text style={styles.loading}>Menyiapkan sesi…</Text></ScreenContainer>;
  if (phase === "done" || !current) return <Completed dayName={day.dayName} focus={day.focus} kcal={kcalDone} doneSets={doneSets} totalSets={totalSets} />;

  const overlay = phase === "rest" || phase === "duration";
  const nextSet = (done[current.id] ?? 0) + 1;
  const ringProgress = total > 0 ? remaining / total : 0;

  return <ScreenContainer className="flex-1" containerClassName="bg-background"><View style={styles.page}>
    <View style={styles.topbar}><Pressable onPress={endPartial} style={({ pressed }) => [styles.end, pressed && styles.pressed]}><MaterialIcons name="close" size={18} color={palette.muted} /><Text style={styles.endText}>Akhiri</Text></Pressable><Tag label={`${kcalDone} kcal`} /></View>
    <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.max(0, (doneSets / totalSets) * 100)}%` }]} /></View><Text style={styles.progressCaption}>Gerakan {currentIndex + 1} dari {day.exercises.length} · {doneSets}/{totalSets} set</Text>
    {overlay ? <TimerView phase={phase} exercise={current} remaining={remaining} total={total} paused={!timerRunning} progress={ringProgress} onPause={togglePause} onAdd={() => addTime(phase === "rest" ? 15 : 300)} onSkip={() => { haptic.medium(); setTimerRunning(false); setEndsAt(null); setRemaining(0); if (phase === "rest") { setPhase("work"); } else { completeSet(current, false); } }} /> : <WorkView exercise={current} nextSet={nextSet} completed={done[current.id] ?? 0} onComplete={() => { haptic.light(); completeSet(current, true); }} onStartDuration={startDuration} />}
  </View></ScreenContainer>;
}

function WorkView({ exercise, nextSet, completed, onComplete, onStartDuration }: { exercise: Exercise; nextSet: number; completed: number; onComplete: () => void; onStartDuration: () => void }) {
  const sets = setsOf(exercise);
  return <View style={styles.work}><Text style={styles.phaseLabel}>Set {Math.min(nextSet, sets)} dari {sets}</Text><Text style={styles.exerciseTitle}>{exercise.name}</Text><Text style={styles.exerciseTarget}>{exercise.durationSeconds ? `${formatClock(exercise.durationSeconds)} durasi` : `Target ${exercise.reps}`}{exercise.note ? ` · ${exercise.note}` : ""}</Text><View style={styles.demo}><ExerciseDemo exercise={exercise} compact /></View><Card style={styles.setCard}><Text style={styles.setNumber}>{sets - completed}</Text><Text style={styles.setCaption}>sisa set</Text><View style={styles.dotRow}>{Array.from({ length: sets }, (_, index) => <View key={index} style={[styles.setDot, index < completed && styles.setDotComplete]} />)}</View></Card>{exercise.durationSeconds ? <PrimaryButton label={`Mulai Timer ${formatClock(exercise.durationSeconds)}`} onPress={onStartDuration} leading={<MaterialIcons name="play-arrow" color="#FFFFFF" size={23} />} /> : <PrimaryButton label="Set Selesai" onPress={onComplete} leading={<MaterialIcons name="check" color="#FFFFFF" size={21} />} />}<Text style={styles.helpText}>Istirahat otomatis {exercise.restSeconds} detik setelah set ditandai selesai.</Text></View>;
}

function TimerView({ phase, exercise, remaining, total, progress, paused, onPause, onAdd, onSkip }: { phase: Phase; exercise: Exercise; remaining: number; total: number; progress: number; paused: boolean; onPause: () => void; onAdd: () => void; onSkip: () => void }) {
  const offset = RING_CIRCUMFERENCE * (1 - Math.max(0, Math.min(1, progress)));
  return <View style={styles.timerView}><Text style={styles.phaseLabel}>{phase === "rest" ? "Waktu Istirahat" : exercise.name}</Text><View style={styles.ring}><Svg width={RING_SIZE} height={RING_SIZE} viewBox="0 0 268 268"><Circle cx="134" cy="134" r={RING_RADIUS} stroke={palette.border} strokeWidth="13" fill="none" /><Circle cx="134" cy="134" r={RING_RADIUS} stroke={palette.primary} strokeWidth="13" fill="none" strokeLinecap="round" strokeDasharray={RING_CIRCUMFERENCE} strokeDashoffset={offset} transform="rotate(-90 134 134)" /></Svg><View style={styles.ringCenter}><Text style={styles.timerText}>{formatClock(remaining)}</Text><Text style={styles.timerHint}>{phase === "rest" ? "Ambil napas dan pulih" : "Tahan posisi / lanjut jalan"}</Text></View></View><View style={styles.timerControls}><Pressable onPress={onAdd} style={({ pressed }) => [styles.timerButton, styles.timerWide, pressed && styles.pressed]}><MaterialIcons name="add" color={palette.text} size={18} /><Text style={styles.timerButtonText}>{phase === "rest" ? "15 detik" : "5 menit"}</Text></Pressable><Pressable onPress={onPause} style={({ pressed }) => [styles.timerButton, styles.timerCircle, pressed && styles.pressed]}><MaterialIcons name={paused ? "play-arrow" : "pause"} color={palette.text} size={22} /></Pressable><Pressable onPress={onSkip} style={({ pressed }) => [styles.skipButton, styles.timerWide, pressed && styles.pressed]}><MaterialIcons name="skip-next" color="#FFFFFF" size={18} /><Text style={styles.skipButtonText}>Lewati</Text></Pressable></View>{paused && <Text style={styles.helpText}>Timer dijeda — tekan tombol putar untuk melanjutkan.</Text>}<Text style={styles.hiddenTotal}>{total}</Text></View>;
}

function Completed({ dayName, focus, kcal, doneSets, totalSets }: { dayName: string; focus: string; kcal: number; doneSets: number; totalSets: number }) {
  return <ScreenContainer className="flex-1" containerClassName="bg-background"><View style={styles.complete}><View style={styles.trophy}><MaterialIcons name="emoji-events" color="#FFFFFF" size={40} /></View><Text style={styles.completeTitle}>Sesi Selesai!</Text><Text style={styles.completeSubtitle}>{dayName} — {focus}</Text><Card style={styles.completeCard}><Text style={styles.kcal}>{kcal}</Text><Text style={styles.kcalCaption}>kcal terbakar</Text><View style={styles.completeStats}><Mini label="Set selesai" value={`${doneSets}/${totalSets}`} /><Mini label="Gerakan" value={String(totalSets)} /></View></Card><PrimaryButton label="Lihat Riwayat" onPress={() => router.replace("/riwayat" as never)} /><Pressable onPress={() => router.replace("/")} style={styles.homeLink}><Text style={styles.homeLinkText}>Kembali ke Beranda</Text></Pressable></View></ScreenContainer>;
}

function Mini({ label, value }: { label: string; value: string }) { return <View style={styles.mini}><Text style={styles.miniValue}>{value}</Text><Text style={styles.miniLabel}>{label}</Text></View>; }

const styles = StyleSheet.create({ page: { flex: 1, padding: 20 }, loading: { color: palette.muted, fontSize: 15 }, topbar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, end: { flexDirection: "row", alignItems: "center", gap: 3, minHeight: 38, paddingHorizontal: 10, borderRadius: 99, borderWidth: 1, borderColor: palette.border }, endText: { color: palette.muted, fontSize: 12, fontWeight: "800" }, progressTrack: { height: 7, backgroundColor: palette.border, overflow: "hidden", borderRadius: 9, marginTop: 20 }, progressFill: { height: "100%", backgroundColor: palette.primary, borderRadius: 9 }, progressCaption: { color: palette.muted, textAlign: "center", fontSize: 12, marginTop: 8 }, work: { flex: 1, alignItems: "center", paddingTop: 34 }, demo: { width: "100%", marginTop: 17, marginBottom: 17 }, phaseLabel: { color: palette.primary, fontSize: 12, fontWeight: "900", textTransform: "uppercase", letterSpacing: 1.4, textAlign: "center" }, exerciseTitle: { color: palette.text, fontSize: 29, lineHeight: 35, fontWeight: "900", textAlign: "center", marginTop: 12 }, exerciseTarget: { color: palette.muted, fontSize: 14, textAlign: "center", marginTop: 8, lineHeight: 20 }, setCard: { width: "100%", alignItems: "center", padding: 28, marginTop: 31, marginBottom: 28 }, setNumber: { color: palette.primary, fontSize: 66, lineHeight: 72, fontWeight: "900" }, setCaption: { color: palette.muted, textTransform: "uppercase", letterSpacing: 1.4, fontSize: 11, fontWeight: "800", marginTop: 5 }, dotRow: { flexDirection: "row", gap: 7, marginTop: 22 }, setDot: { width: 27, height: 8, borderRadius: 9, backgroundColor: palette.border }, setDotComplete: { backgroundColor: palette.success }, helpText: { color: palette.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 12 }, timerView: { flex: 1, alignItems: "center", paddingTop: 39 }, ring: { width: RING_SIZE, height: RING_SIZE, justifyContent: "center", alignItems: "center", marginTop: 22 }, ringCenter: { position: "absolute", alignItems: "center", paddingHorizontal: 35 }, timerText: { color: palette.text, fontSize: 51, fontWeight: "900", fontVariant: ["tabular-nums"] }, timerHint: { color: palette.muted, fontSize: 12, textAlign: "center", lineHeight: 17, marginTop: 8 }, timerControls: { flexDirection: "row", gap: 9, marginTop: 31, width: "100%" }, timerButton: { minHeight: 54, borderRadius: 16, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 4 }, timerWide: { flex: 1 }, timerCircle: { width: 54 }, timerButtonText: { color: palette.text, fontSize: 12, fontWeight: "900" }, skipButton: { minHeight: 54, borderRadius: 16, backgroundColor: palette.primary, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 4 }, skipButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, hiddenTotal: { display: "none" }, pressed: { opacity: 0.88, transform: [{ scale: 0.98 }] }, complete: { flex: 1, alignItems: "center", paddingHorizontal: 20, paddingTop: 64 }, trophy: { width: 82, height: 82, borderRadius: 28, alignItems: "center", justifyContent: "center", backgroundColor: palette.primary, shadowColor: palette.primaryDark, shadowOpacity: 0.24, shadowRadius: 16, elevation: 5 }, completeTitle: { color: palette.text, fontSize: 31, fontWeight: "900", marginTop: 22 }, completeSubtitle: { color: palette.muted, fontSize: 14, marginTop: 7 }, completeCard: { width: "100%", alignItems: "center", marginTop: 29, marginBottom: 26, padding: 24 }, kcal: { color: palette.primary, fontSize: 54, fontWeight: "900" }, kcalCaption: { color: palette.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", letterSpacing: 1.5 }, completeStats: { flexDirection: "row", gap: 10, width: "100%", marginTop: 23 }, mini: { flex: 1, backgroundColor: palette.surfaceMuted, padding: 14, borderRadius: 15 }, miniValue: { color: palette.text, fontSize: 18, fontWeight: "900" }, miniLabel: { color: palette.muted, fontSize: 11, marginTop: 3 }, homeLink: { paddingVertical: 18 }, homeLinkText: { color: palette.muted, fontSize: 14, fontWeight: "700" }, });
