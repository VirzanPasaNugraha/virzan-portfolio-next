import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Card, palette, PrimaryButton, SectionTitle, Tag } from "@/components/bulk-ui";
import { formatClock, getDayById, getDayByIndex, getTodayIndex, totalSetsOf } from "@/data/bulk";

export default function DayDetailScreen() {
  const { dayId } = useLocalSearchParams<{ dayId: string }>();
  const day = getDayById(dayId);
  const isToday = day?.id === getDayByIndex(getTodayIndex()).id;

  if (!day) return <ScreenContainer className="flex-1 p-5"><Text style={styles.error}>Jadwal tidak ditemukan.</Text></ScreenContainer>;

  return <ScreenContainer className="flex-1" containerClassName="bg-background">
    <FlatList
      data={day.exercises}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.list}
      showsVerticalScrollIndicator={false}
      ListHeaderComponent={<View><Pressable onPress={() => router.back()} style={styles.back}><MaterialIcons name="arrow-back" size={19} color={palette.text} /><Text style={styles.backText}>Kembali</Text></Pressable><Text style={styles.kicker}>{day.dayName}</Text><Text style={styles.title}>{day.focus}</Text><Text style={styles.subtitle}>{day.muscles}</Text><View style={styles.summary}><Tag label={`${day.exercises.length} gerakan`} /><Tag label={`${totalSetsOf(day)} set`} tone="gray" /><Tag label={`${day.kcalMin === day.kcalMax ? day.kcalMin : `${day.kcalMin}–${day.kcalMax}`} kcal`} tone="amber" /></View><View style={styles.heading}><SectionTitle>Rencana Latihan</SectionTitle></View></View>}
      renderItem={({ item, index }) => <Pressable onPress={() => router.push(`/exercise/${item.id}` as never)} accessibilityRole="button" accessibilityLabel={`Lihat gambar gerakan ${item.name}`} style={({ pressed }) => [styles.exercisePressable, pressed && styles.pressed]}><Card style={styles.exercise}><View style={styles.number}><Text style={styles.numberText}>{index + 1}</Text></View><View style={styles.copy}><Text style={styles.exerciseName}>{item.name}</Text><Text style={styles.detail}>{item.sets ? `${item.sets} set · ${item.reps ?? formatClock(item.durationSeconds ?? 0)}` : `${formatClock(item.durationSeconds ?? 0)} durasi`}</Text><Text style={styles.rest}>Istirahat {item.restSeconds} detik{item.note ? ` · ${item.note}` : ""}</Text></View><Tag label={`${item.kcal}`} /><MaterialIcons name="play-circle-outline" color="#FFFFFF" size={22} /></Card></Pressable>}
      ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      ListFooterComponent={<View style={styles.footer}>{isToday ? <PrimaryButton label="Mulai Sesi Hari Ini" onPress={() => router.push("/session" as never)} leading={<MaterialIcons name="play-arrow" color="#FFFFFF" size={22} />} /> : <View style={styles.notice}><MaterialIcons name="info-outline" color={palette.warning} size={19} /><Text style={styles.noticeText}>Jadwal dapat dilihat kapan saja, tetapi sesi hanya dapat dijalankan pada hari kalender yang sesuai.</Text></View>}</View>}
    />
  </ScreenContainer>;
}

const styles = StyleSheet.create({ list: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 26, width: "100%", maxWidth: 560, alignSelf: "center" }, exercisePressable: { width: "100%" }, back: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 5, minHeight: 38 }, backText: { color: palette.text, fontSize: 14, fontWeight: "800" }, kicker: { color: palette.primary, fontSize: 12, fontWeight: "900", textTransform: "uppercase", letterSpacing: 1.3, marginTop: 18 }, title: { color: palette.text, fontSize: 31, fontWeight: "900", lineHeight: 38, marginTop: 5 }, subtitle: { color: palette.muted, fontSize: 15, marginTop: 4 }, summary: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 17 }, heading: { marginTop: 27 }, exercise: { flexDirection: "row", padding: 14, gap: 12 }, number: { height: 32, width: 32, alignItems: "center", justifyContent: "center", borderRadius: 11, backgroundColor: palette.surfaceMuted }, numberText: { color: palette.primary, fontWeight: "900" }, copy: { flex: 1 }, exerciseName: { color: palette.text, fontSize: 15, fontWeight: "800", lineHeight: 20 }, detail: { color: palette.muted, fontSize: 13, marginTop: 4 }, rest: { color: palette.muted, fontSize: 12, marginTop: 3 }, footer: { marginTop: 25 }, notice: { flexDirection: "row", gap: 9, padding: 15, backgroundColor: palette.warningSoft, borderRadius: 18 }, noticeText: { flex: 1, color: palette.warning, fontSize: 13, lineHeight: 19 }, error: { color: palette.text, fontSize: 16 }, pressed: { opacity: 0.75 }, });
