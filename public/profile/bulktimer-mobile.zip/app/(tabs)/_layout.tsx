import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { palette } from "@/components/bulk-ui";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomInset = Math.max(insets.bottom, Platform.OS === "android" ? 10 : 8);
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: palette.primary,
      tabBarInactiveTintColor: palette.muted,
      tabBarLabelStyle: { fontWeight: "700", fontSize: 11, marginTop: -2 },
      tabBarStyle: { height: 55 + bottomInset, paddingTop: 7, paddingBottom: bottomInset, borderTopColor: palette.border, borderTopWidth: 1, backgroundColor: palette.background, elevation: 0 },
    }}>
      <Tabs.Screen name="index" options={{ title: "Hari Ini", tabBarIcon: ({ color, size }) => <MaterialIcons name="today" color={color} size={size} /> }} />
      <Tabs.Screen name="riwayat" options={{ title: "Riwayat", tabBarIcon: ({ color, size }) => <MaterialIcons name="history" color={color} size={size} /> }} />
      <Tabs.Screen name="tips" options={{ title: "Nutrisi", tabBarIcon: ({ color, size }) => <MaterialIcons name="restaurant-menu" color={color} size={size} /> }} />
      <Tabs.Screen name="panduan" options={{ title: "Panduan", tabBarIcon: ({ color, size }) => <MaterialIcons name="menu-book" color={color} size={size} /> }} />
    </Tabs>
  );
}
