import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { Card, palette, SectionTitle } from "@/components/bulk-ui";
import { APP_DEVELOPER } from "@/data/bulk";
import { ScreenContainer } from "@/components/screen-container";

const steps = [
  ["Buka jadwal hari ini", "BulkTimer otomatis memilih jadwal latihan berdasarkan hari kalender."],
  ["Mulai sesi", "Tekan Mulai Latihan dari Beranda untuk menjalankan urutan gerakan."],
  ["Tandai set selesai", "Set berbasis repetisi akan berpindah ke waktu istirahat otomatis."],
  ["Jalankan timer", "Untuk gerakan berdurasi, gunakan timer hingga latihan selesai."],
  ["Lihat progres", "Sesi selesai atau sebagian tersimpan di Riwayat perangkat."],
];

export default function GuideTab() {
  return (
    <ScreenContainer className="flex-1" containerClassName="bg-background">
      <FlatList
        data={steps}
        keyExtractor={(item) => item[0]}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={<View><Text style={styles.title}>Panduan</Text><Text style={styles.subtitle}>Ikuti langkah singkat ini untuk memakai BulkTimer saat latihan.</Text><View style={styles.section}><SectionTitle>Cara Menggunakan</SectionTitle></View></View>}
        renderItem={({ item, index }) => <Card style={styles.step}><View style={styles.stepNumber}><Text style={styles.stepNumberText}>{index + 1}</Text></View><View style={styles.stepCopy}><Text style={styles.stepTitle}>{item[0]}</Text><Text style={styles.stepText}>{item[1]}</Text></View></Card>}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListFooterComponent={<View style={styles.footer}><SectionTitle>Informasi</SectionTitle><Text style={styles.developer}>Dikembangkan oleh {APP_DEVELOPER}</Text><Pressable onPress={() => router.push("/legal/privacy" as never)} style={({ pressed }) => [styles.link, pressed && styles.pressed]}><Text style={styles.linkText}>Kebijakan Privasi</Text><MaterialIcons name="chevron-right" size={21} color={palette.muted} /></Pressable><Pressable onPress={() => router.push("/legal/terms" as never)} style={({ pressed }) => [styles.link, pressed && styles.pressed]}><Text style={styles.linkText}>Persyaratan Penggunaan</Text><MaterialIcons name="chevron-right" size={21} color={palette.muted} /></Pressable></View>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  list: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 26, width: "100%", maxWidth: 560, alignSelf: "center" },
  title: { color: palette.text, fontSize: 31, fontWeight: "900" },
  subtitle: { color: palette.muted, fontSize: 14, lineHeight: 20, marginTop: 6 },
  section: { marginTop: 27 },
  step: { flexDirection: "row", gap: 13, padding: 15 },
  stepNumber: { width: 32, height: 32, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: palette.primarySoft },
  stepNumberText: { color: palette.primary, fontSize: 14, fontWeight: "900" },
  stepCopy: { flex: 1 },
  stepTitle: { color: palette.text, fontSize: 15, fontWeight: "900" },
  stepText: { color: palette.muted, fontSize: 13, lineHeight: 19, marginTop: 4 },
  footer: { marginTop: 28 },
  developer: { color: palette.muted, fontSize: 12, marginTop: -4, marginBottom: 12 },
  link: { flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 17, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, marginBottom: 9 },
  linkText: { color: palette.text, fontSize: 14, fontWeight: "800", flex: 1 },
  pressed: { opacity: 0.75 },
});
