import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useFocusEffect } from "@react-navigation/native";
import { router } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useCallback, useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Card, palette, PrimaryButton, SectionTitle, Tag } from "@/components/bulk-ui";
import { formatClock, getDayByIndex, getTodayIndex, SCHEDULE, setsOf, totalSetsOf, type Exercise, type WorkoutDay } from "@/data/bulk";
import { loadSession } from "@/lib/bulk-storage";

type HomeItem =
  | { id: string; kind: "exercise"; value: Exercise; index: number }
  | { id: string; kind: "day"; value: WorkoutDay; index: number };

export default function HomeScreen() {
  const todayIndex = getTodayIndex();
  const today = getDayByIndex(todayIndex);
  const [resume, setResume] = useState(false);

  useFocusEffect(useCallback(() => {
    void loadSession().then((session) => setResume(Boolean(session && session.dayId === today.id)));
  }, [today.id]));

  const data = useMemo<HomeItem[]>(() => [
    ...today.exercises.map((exercise, index) => ({ id: `exercise-${exercise.id}`, kind: "exercise" as const, value: exercise, index })),
    ...SCHEDULE.map((day, index) => ({ id: `day-${day.id}`, kind: "day" as const, value: day, index })),
  ], [today]);

  const dateLabel = new Intl.DateTimeFormat("id-ID", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
  const kcalLabel = today.kcalMin === today.kcalMax ? `${today.kcalMin}` : `${today.kcalMin}–${today.kcalMax}`;
  const timeBasedMinutes = today.exercises.reduce((total, exercise) => total + (exercise.durationSeconds ?? 0) * setsOf(exercise), 0) / 60;

  return (
    <ScreenContainer className="flex-1" containerClassName="bg-background">
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            <View style={styles.brandRow}>
              <View style={styles.logo}><MaterialIcons name="timer" color="#FFFFFF" size={20} /></View>
              <View style={styles.brandCopy}><Text style={styles.brandName}>VirzanWorkout</Text><Text style={styles.brandCaption}>Latihan bulking harian</Text></View>
              <Tag label="Offline" tone="gray" />
            </View>
            <LinearGradient colors={[palette.primary, palette.primaryDeep, "#9F3740"]} start={{ x: 0.05, y: 0 }} end={{ x: 0.92, y: 1 }} style={styles.hero}>
              <Text style={styles.heroDate}>{dateLabel}</Text>
              <Text style={styles.heroDay}>{today.dayName}</Text>
              <Text style={styles.heroFocus}>{today.focus}</Text>
              <Text style={styles.heroMuscles}>{today.muscles}</Text>
              <View style={styles.statRow}>
                <Stat label="Gerakan" value={String(today.exercises.length)} />
                <Stat label="Total Set" value={String(totalSetsOf(today))} />
                <Stat label="Kalori" value={kcalLabel} />
              </View>
              <PrimaryButton label={resume ? "Lanjutkan Sesi" : today.type === "training" ? "Mulai Latihan" : "Mulai Aktivitas"} onPress={() => router.push("/session" as never)} leading={<MaterialIcons name="play-arrow" color="#FFFFFF" size={22} />} />
            </LinearGradient>
            <View style={styles.sectionHeader}><SectionTitle>{today.type === "training" ? "Gerakan Hari Ini" : "Aktivitas Hari Ini"}</SectionTitle></View>
          </View>
        }
        renderItem={({ item }) => item.kind === "exercise" ? (
          <ExerciseRow exercise={item.value} index={item.index} />
        ) : item.index === 0 ? (
          <View style={styles.weeklyStart}><SectionTitle>Jadwal Mingguan</SectionTitle><DayCard day={item.value} isToday={item.index === todayIndex} /></View>
        ) : (
          <DayCard day={item.value} isToday={item.index === todayIndex} />
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListFooterComponent={timeBasedMinutes > 0 ? <View style={styles.timeNote}><MaterialIcons name="auto-awesome" color={palette.primary} size={17} /><Text style={styles.timeNoteText}>Gerakan berbasis waktu hari ini sekitar {Math.round(timeBasedMinutes)} menit. Timer berjalan otomatis ketika dimulai.</Text></View> : null}
      />
    </ScreenContainer>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>;
}

function ExerciseRow({ exercise, index }: { exercise: Exercise; index: number }) {
  const detail = exercise.durationSeconds ? formatClock(exercise.durationSeconds) : exercise.reps;
  return <Pressable onPress={() => router.push(`/exercise/${exercise.id}` as never)} accessibilityRole="button" accessibilityLabel={`Lihat gambar gerakan ${exercise.name}`} style={({ pressed }) => [styles.rowPressable, pressed && styles.pressed]}>
    <Card style={styles.exerciseCard}>
      <View style={styles.exerciseIndex}><Text style={styles.exerciseIndexText}>{index + 1}</Text></View>
      <View style={styles.exerciseCopy}><Text numberOfLines={2} style={styles.exerciseName}>{exercise.name}</Text><Text style={styles.exerciseDetail}>{exercise.sets ? `${exercise.sets} set` : "1 sesi"} · {detail}{exercise.note ? ` · ${exercise.note}` : ""}</Text></View>
      <Tag label={`${exercise.kcal} kcal`} />
      <MaterialIcons name="play-circle-outline" color="#FFFFFF" size={22} />
    </Card>
  </Pressable>;
}

function DayCard({ day, isToday }: { day: WorkoutDay; isToday: boolean }) {
  return <Pressable onPress={() => router.push(`/day/${day.id}` as never)} style={({ pressed }) => [styles.dayCard, isToday && styles.dayCardToday, pressed && styles.pressed]}>
    <View style={styles.dayTop}><Text style={styles.dayName}>{day.dayName}</Text>{isToday && <Tag label="Hari ini" />}</View>
    <Text style={styles.dayFocus}>{day.focus}</Text><Text style={styles.dayMuscles}>{day.muscles}</Text>
    <View style={styles.dayBottom}><Text style={styles.dayMeta}>{day.exercises.length} gerakan · {totalSetsOf(day)} set</Text><MaterialIcons name="chevron-right" color={palette.muted} size={20} /></View>
  </Pressable>;
}

const styles = StyleSheet.create({
  list: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 26, width: "100%", maxWidth: 560, alignSelf: "center" }, rowPressable: { width: "100%" }, brandRow: { flexDirection: "row", alignItems: "center", marginBottom: 18 }, logo: { width: 38, height: 38, borderRadius: 12, backgroundColor: palette.primary, justifyContent: "center", alignItems: "center" }, brandCopy: { flex: 1, marginLeft: 10 }, brandName: { color: palette.text, fontSize: 17, fontWeight: "900" }, brandCaption: { color: palette.muted, fontSize: 12, marginTop: 1 }, hero: { borderRadius: 28, padding: 22, shadowColor: palette.primary, shadowOpacity: 0.32, shadowRadius: 18, elevation: 7 }, heroDate: { color: "#FFE2C8", fontSize: 12, fontWeight: "800", textTransform: "uppercase", letterSpacing: 1.2 }, heroDay: { color: "#FFF9F6", fontSize: 36, lineHeight: 42, fontWeight: "900", marginTop: 6 }, heroFocus: { color: "#FFF9F6", fontSize: 19, fontWeight: "800", marginTop: 3 }, heroMuscles: { color: "#FFE2C8", fontSize: 14, marginTop: 3 }, statRow: { flexDirection: "row", gap: 8, marginTop: 19, marginBottom: 18 }, stat: { flex: 1, minWidth: 0, backgroundColor: "rgba(42,16,16,0.18)", borderRadius: 15, paddingHorizontal: 10, paddingVertical: 10 }, statValue: { color: "#FFF9F6", fontSize: 17, fontWeight: "900" }, statLabel: { color: "#FFE2C8", fontSize: 10, fontWeight: "700", marginTop: 3, textTransform: "uppercase" }, sectionHeader: { marginTop: 26 }, exerciseCard: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13 }, exerciseIndex: { width: 34, height: 34, justifyContent: "center", alignItems: "center", borderRadius: 11, backgroundColor: palette.surfaceMuted }, exerciseIndexText: { color: palette.primary, fontSize: 14, fontWeight: "900" }, exerciseCopy: { flex: 1 }, exerciseName: { color: palette.text, fontSize: 14, fontWeight: "800" }, exerciseDetail: { color: palette.muted, fontSize: 12, marginTop: 3 }, weeklyStart: { marginTop: 26 }, dayCard: { backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, borderRadius: 20, padding: 16 }, dayCardToday: { borderColor: palette.primary, borderWidth: 1.5 }, dayTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, dayName: { color: palette.muted, fontSize: 12, fontWeight: "700" }, dayFocus: { color: palette.text, fontSize: 17, fontWeight: "900", marginTop: 5 }, dayMuscles: { color: palette.muted, fontSize: 13, marginTop: 3 }, dayBottom: { flexDirection: "row", alignItems: "center", marginTop: 12 }, dayMeta: { color: palette.muted, fontSize: 12, flex: 1 }, separator: { height: 10 }, timeNote: { flexDirection: "row", gap: 8, padding: 14, borderRadius: 18, backgroundColor: palette.surfaceMuted, borderWidth: 1, borderColor: palette.border, marginTop: 26 }, timeNoteText: { color: palette.muted, fontSize: 12, lineHeight: 18, flex: 1 }, pressed: { opacity: 0.88, transform: [{ scale: 0.985 }] },
});
