/** @type {const} */
const themeColors = {
  primary: { light: '#FF8A31', dark: '#FF8A31' },
  background: { light: '#24262D', dark: '#24262D' },
  surface: { light: '#30323A', dark: '#30323A' },
  foreground: { light: '#F9FAFB', dark: '#F9FAFB' },
  muted: { light: '#D5D7E0', dark: '#D5D7E0' },
  border: { light: '#555966', dark: '#555966' },
  success: { light: '#71E5A9', dark: '#71E5A9' },
  warning: { light: '#F9BC5C', dark: '#F9BC5C' },
  error: { light: '#F45B57', dark: '#F45B57' },
};

module.exports = { themeColors };
