# Distribusi BulkTimer Tanpa Google Play Store

BulkTimer disiapkan sebagai aplikasi Android yang dapat dipasang dari berkas APK. Untuk menghasilkan APK, gunakan tombol **Publish** pada antarmuka proyek setelah checkpoint tersedia. Proses tersebut menjalankan build Android yang dikelola platform dan menyediakan APK untuk diunduh.

Setelah APK tersedia, berkas tersebut dapat dibagikan langsung kepada pengguna Android. Jika ingin memakai tautan Google Drive, unggah APK hasil unduhan ke Google Drive, lalu atur akses berbagi menjadi **Anyone with the link**. Pengguna cukup membuka tautan tersebut, mengunduh APK, dan menyetujui izin pemasangan dari sumber yang diizinkan pada perangkat Android mereka.

> Jangan membagikan berkas APK yang belum diuji kepada pengguna luas. Setiap perubahan kode memerlukan build APK baru agar versi yang dibagikan sesuai dengan aplikasi terbaru.
