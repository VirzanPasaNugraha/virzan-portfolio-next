import { describe, expect, it } from "vitest";
import { formatClock, getDayByIndex, getTodayIndex, getExerciseById, SCHEDULE, totalSetsOf } from "../data/bulk";

describe("jadwal BulkTimer", () => {
  it("menyediakan tujuh hari jadwal berurutan dari Senin hingga Minggu", () => {
    expect(SCHEDULE).toHaveLength(7);
    expect(SCHEDULE[0]?.id).toBe("senin");
    expect(SCHEDULE[6]?.id).toBe("minggu");
  });

  it("mengonversi hari JavaScript menjadi indeks jadwal yang dimulai Senin", () => {
    expect(getTodayIndex(new Date("2026-08-17T12:00:00"))).toBe(0);
    expect(getTodayIndex(new Date("2026-08-23T12:00:00"))).toBe(6);
  });

  it("menghitung jumlah set hari latihan dan menampilkan format timer", () => {
    expect(totalSetsOf(getDayByIndex(0))).toBe(15);
    expect(formatClock(65.1)).toBe("01:06");
    expect(formatClock(-10)).toBe("00:00");
  });

  it("menemukan setiap gerakan berdasarkan ID untuk layar animasi", () => {
    const exercises = SCHEDULE.flatMap((day) => day.exercises);
    expect(exercises.every((exercise) => getExerciseById(exercise.id)?.name === exercise.name)).toBe(true);
  });

});
