from pathlib import Path
from PIL import Image
import shutil

source_dir = Path('/home/ubuntu/webdev-static-assets')
target_dir = Path('/home/ubuntu/bulktimer-mobile/assets/exercises')
target_dir.mkdir(parents=True, exist_ok=True)

names = ['push-up', 'row', 'lateral-raise', 'dips', 'face-pull', 'calf']
for name in names:
    source = source_dir / f'{name}.png'
    if not source.exists():
        continue
    with Image.open(source) as image:
        image = image.convert('RGB')
        image.thumbnail((760, 510), Image.Resampling.LANCZOS)
        image.save(target_dir / f'{name}.webp', 'WEBP', quality=78, method=6)

fallback = target_dir / 'push-up.webp'
if fallback.exists():
    for name in ['pull', 'press', 'curl', 'squat', 'lunge', 'bridge', 'plank', 'twist', 'stretch', 'walk']:
        destination = target_dir / f'{name}.webp'
        if not destination.exists():
            shutil.copyfile(fallback, destination)
