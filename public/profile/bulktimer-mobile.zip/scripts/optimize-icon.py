from pathlib import Path

from PIL import Image

project = Path("/home/ubuntu/bulktimer-mobile")
source = project / "assets/images/icon.png"
targets = [
    project / "assets/images/icon.png",
    project / "assets/images/splash-icon.png",
    project / "assets/images/favicon.png",
    project / "assets/images/android-icon-foreground.png",
]

with Image.open(source) as image:
    rgb = image.convert("RGBA")
    optimized = rgb.resize((512, 512), Image.Resampling.LANCZOS)
    for target in targets:
        optimized.save(target, format="PNG", optimize=True, compress_level=9)
