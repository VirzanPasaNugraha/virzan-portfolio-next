import type { Exercise } from "@/data/bulk";

export const exerciseImages = {
  push: require("../assets/exercises/push-up.webp"),
  pull: require("../assets/exercises/pull.webp"),
  press: require("../assets/exercises/press.webp"),
  curl: require("../assets/exercises/curl.webp"),
  squat: require("../assets/exercises/squat.webp"),
  lunge: require("../assets/exercises/lunge.webp"),
  bridge: require("../assets/exercises/bridge.webp"),
  plank: require("../assets/exercises/plank.webp"),
  twist: require("../assets/exercises/twist.webp"),
  stretch: require("../assets/exercises/stretch.webp"),
  walk: require("../assets/exercises/walk.webp"),
  row: require("../assets/exercises/row.webp"),
  lateralRaise: require("../assets/exercises/lateral-raise.webp"),
  dips: require("../assets/exercises/dips.webp"),
  facePull: require("../assets/exercises/face-pull.webp"),
  calf: require("../assets/exercises/calf.webp"),
} as const;

export type ExerciseImageKey = keyof typeof exerciseImages;

export function imageKeyForExercise(exercise: Exercise): ExerciseImageKey {
  const name = exercise.name.toLowerCase();
  if (name.includes("push up")) return "push";
  if (name.includes("pull up")) return "pull";
  if (name.includes("dumbbell row")) return "row";
  if (name.includes("face pull")) return "facePull";
  if (name.includes("shoulder press")) return "press";
  if (name.includes("lateral raise")) return "lateralRaise";
  if (name.includes("bicep curl")) return "curl";
  if (name.includes("triceps dips")) return "dips";
  if (name.includes("squat")) return "squat";
  if (name.includes("lunge")) return "lunge";
  if (name.includes("bridge") || name.includes("hip thrust")) return "bridge";
  if (name.includes("calf raise")) return "calf";
  if (name.includes("plank")) return "plank";
  if (name.includes("russian twist")) return "twist";
  if (name.includes("stretch") || name.includes("yoga")) return "stretch";
  if (name.includes("jalan")) return "walk";
  return "press";
}

export function imageForExercise(exercise: Exercise) {
  return exerciseImages[imageKeyForExercise(exercise)];
}
