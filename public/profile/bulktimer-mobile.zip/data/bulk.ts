export type WorkoutType = "training" | "active_rest" | "recovery";

export interface Exercise {
  id: string;
  name: string;
  sets?: number;
  reps?: string;
  durationSeconds?: number;
  kcal: number;
  restSeconds: number;
  note?: string;
}

export interface WorkoutDay {
  id: string;
  dayName: string;
  short: string;
  focus: string;
  muscles: string;
  type: WorkoutType;
  kcalMin: number;
  kcalMax: number;
  exercises: Exercise[];
}

const REST_SET = 60;
const REST_MOVE = 90;

export const SCHEDULE: WorkoutDay[] = [
  { id: "senin", dayName: "Senin", short: "Sen", focus: "Push Day", muscles: "Dada • Bahu • Triceps", type: "training", kcalMin: 230, kcalMax: 230, exercises: [
    { id: "s1", name: "Push Up", sets: 4, reps: "15–20 reps", kcal: 80, restSeconds: REST_SET },
    { id: "s2", name: "Shoulder Press (Dumbbell 5kg)", sets: 4, reps: "12 reps", kcal: 48, restSeconds: REST_SET },
    { id: "s3", name: "Side Lateral Raise", sets: 3, reps: "15 reps", kcal: 30, restSeconds: REST_SET },
    { id: "s4", name: "Triceps Dips (Pakai Kursi)", sets: 3, reps: "12–15 reps", kcal: 36, restSeconds: REST_SET },
    { id: "s5", name: "Jalan Cepat", durationSeconds: 20 * 60, kcal: 90, restSeconds: REST_MOVE },
  ] },
  { id: "selasa", dayName: "Selasa", short: "Sel", focus: "Pull Day", muscles: "Punggung • Biceps", type: "training", kcalMin: 235, kcalMax: 270, exercises: [
    { id: "t1", name: "Pull Up", sets: 4, reps: "Maksimal", kcal: 80, restSeconds: REST_SET, note: "Maksimal kemampuan" },
    { id: "t2", name: "Dumbbell Row (5kg, bergantian)", sets: 4, reps: "12 reps", kcal: 48, restSeconds: REST_SET },
    { id: "t3", name: "Bicep Curl (5kg)", sets: 4, reps: "12–15 reps", kcal: 40, restSeconds: REST_SET },
    { id: "t4", name: "Face Pull (Resistance Band)", sets: 3, reps: "15 reps", kcal: 30, restSeconds: REST_SET },
    { id: "t5", name: "Jalan Cepat", durationSeconds: 20 * 60, kcal: 90, restSeconds: REST_MOVE, note: "Target 20–30 menit" },
  ] },
  { id: "rabu", dayName: "Rabu", short: "Rab", focus: "Legs Day", muscles: "Kaki", type: "training", kcalMin: 220, kcalMax: 220, exercises: [
    { id: "r1", name: "Squat (Bodyweight/Dumbbell)", sets: 4, reps: "15 reps", kcal: 60, restSeconds: REST_SET },
    { id: "r2", name: "Lunges (bergantian kaki)", sets: 3, reps: "12 reps/kaki", kcal: 48, restSeconds: REST_SET },
    { id: "r3", name: "Hamstring Bridge / Hip Thrust", sets: 3, reps: "15 reps", kcal: 30, restSeconds: REST_SET },
    { id: "r4", name: "Calf Raise", sets: 4, reps: "20–25 reps", kcal: 40, restSeconds: REST_SET },
    { id: "r5", name: "Jalan Cepat", durationSeconds: 20 * 60, kcal: 90, restSeconds: REST_MOVE },
  ] },
  { id: "kamis", dayName: "Kamis", short: "Kam", focus: "Istirahat Aktif", muscles: "Pemulihan ringan", type: "active_rest", kcalMin: 131, kcalMax: 131, exercises: [
    { id: "k1", name: "Jalan Cepat Santai", durationSeconds: 30 * 60, kcal: 105, restSeconds: REST_MOVE },
    { id: "k2", name: "Stretching / Yoga Ringan", durationSeconds: 15 * 60, kcal: 26, restSeconds: 0 },
  ] },
  { id: "jumat", dayName: "Jumat", short: "Jum", focus: "Full Upper", muscles: "Dada • Punggung • Lengan", type: "training", kcalMin: 190, kcalMax: 260, exercises: [
    { id: "j1", name: "Push Up", sets: 3, reps: "20 reps", kcal: 64, restSeconds: REST_SET },
    { id: "j2", name: "Pull Up", sets: 3, reps: "Maksimal", kcal: 64, restSeconds: REST_SET },
    { id: "j3", name: "Shoulder Press (Dumbbell)", sets: 3, reps: "12 reps", kcal: 36, restSeconds: REST_SET },
    { id: "j4", name: "Bicep Curl", sets: 3, reps: "12 reps", kcal: 30, restSeconds: REST_SET },
    { id: "j5", name: "Triceps Dips", sets: 3, reps: "12–15 reps", kcal: 36, restSeconds: REST_SET },
    { id: "j6", name: "Jalan Cepat (Opsional)", durationSeconds: 20 * 60, kcal: 90, restSeconds: REST_MOVE },
  ] },
  { id: "sabtu", dayName: "Sabtu", short: "Sab", focus: "Legs + Core", muscles: "Kaki • Perut", type: "training", kcalMin: 215, kcalMax: 250, exercises: [
    { id: "b1", name: "Squat", sets: 4, reps: "15 reps", kcal: 60, restSeconds: REST_SET },
    { id: "b2", name: "Calf Raise", sets: 3, reps: "25 reps", kcal: 30, restSeconds: REST_SET },
    { id: "b3", name: "Lunges", sets: 3, reps: "12 reps/kaki", kcal: 48, restSeconds: REST_SET },
    { id: "b4", name: "Plank", sets: 3, durationSeconds: 45, kcal: 18, restSeconds: REST_SET },
    { id: "b5", name: "Russian Twist", sets: 3, reps: "20 reps", kcal: 20, restSeconds: REST_SET },
    { id: "b6", name: "Jalan Cepat", durationSeconds: 20 * 60, kcal: 90, restSeconds: REST_MOVE, note: "Target 20–30 menit" },
  ] },
  { id: "minggu", dayName: "Minggu", short: "Min", focus: "Recovery", muscles: "Pemulihan total", type: "recovery", kcalMin: 131, kcalMax: 131, exercises: [
    { id: "m1", name: "Jalan Cepat Santai", durationSeconds: 30 * 60, kcal: 105, restSeconds: REST_MOVE },
    { id: "m2", name: "Stretching Seluruh Tubuh", durationSeconds: 15 * 60, kcal: 26, restSeconds: 0 },
  ] },
];

export const NUTRITION = {
  targetKcal: "2.700 – 2.900 kcal / hari",
  macros: [
    { label: "Protein", value: "1,8 – 2,2 g per kg berat badan", pct: 30 },
    { label: "Karbohidrat", value: "4 – 6 g per kg berat badan", pct: 50 },
    { label: "Lemak Sehat", value: "0,8 – 1 g per kg berat badan", pct: 20 },
  ],
  meals: [
    { time: "06.30 — Sarapan", items: "Nasi + telur 3 butir + tempe, susu full cream" },
    { time: "10.00 — Snack", items: "Pisang + selai kacang / roti gandum" },
    { time: "12.30 — Makan Siang", items: "Nasi + ayam dada 150g + sayur + tahu" },
    { time: "16.00 — Pre-Workout", items: "Oat + madu + susu" },
    { time: "19.00 — Makan Malam", items: "Nasi + ikan/daging + sayur + telur" },
    { time: "21.30 — Sebelum Tidur", items: "Susu full cream + kacang almond" },
  ],
  tips: [
    "Surplus kalori 300–500 kcal dari kebutuhan harian, jangan berlebihan supaya lemak tidak ikut naik.",
    "Tidur 7–8 jam; hipertrofi otot terjadi paling besar saat istirahat.",
    "Minum air 2,5–3 liter per hari, tambah saat sesi jalan cepat.",
    "Naikkan beban atau repetisi tiap 1–2 minggu secara bertahap.",
    "Timbang berat badan seminggu sekali, pagi setelah bangun tidur.",
  ],
};

export function getTodayIndex(date: Date = new Date()) {
  return (date.getDay() + 6) % 7;
}

export function getDayByIndex(index: number) {
  return SCHEDULE[index] ?? SCHEDULE[0];
}

export function getDayById(id: string) {
  return SCHEDULE.find((day) => day.id === id);
}

export const APP_DEVELOPER = "Virzan Pasa Nugraha";

export function getExerciseById(id: string) {
  for (const day of SCHEDULE) {
    const exercise = day.exercises.find((item) => item.id === id);
    if (exercise) return exercise;
  }
  return undefined;
}

export function setsOf(exercise: Exercise) {
  return exercise.sets ?? 1;
}

export function totalSetsOf(day: WorkoutDay) {
  return day.exercises.reduce((total, exercise) => total + setsOf(exercise), 0);
}

export function formatClock(seconds: number) {
  const safeSeconds = Math.max(0, Math.ceil(seconds));
  const minutes = Math.floor(safeSeconds / 60);
  return `${String(minutes).padStart(2, "0")}:${String(safeSeconds % 60).padStart(2, "0")}`;
}

export function todayKey(date: Date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
