# Rancangan Antarmuka BulkTimer

## Tujuan Produk

BulkTimer adalah timer pendamping program latihan *bulking* yang membantu pengguna mengikuti jadwal latihan harian, menjalankan sesi dengan interval yang jelas, melihat riwayat, serta membaca panduan dasar. Aplikasi dirancang untuk penggunaan satu tangan dalam orientasi potret 9:16. Tampilan mengikuti pola iOS modern: area aman yang lapang, hierarki teks jelas, tombol utama yang mudah dijangkau di bagian bawah, dan navigasi tab yang konsisten.

## Daftar Layar

| Layar | Konten utama | Fungsi utama |
|---|---|---|
| Beranda | Ringkasan hari aktif, progres mingguan, kartu latihan berikutnya, dan tombol mulai | Membuka detail jadwal latihan atau memulai sesi saat ini |
| Detail Hari | Judul hari latihan, fokus otot, daftar latihan, durasi, repetisi, dan waktu istirahat | Meninjau rencana dan memulai sesi untuk hari yang dipilih |
| Sesi Aktif | Nama latihan, nomor set, penghitung waktu besar, indikator progres, kontrol jeda/lanjut/selesai | Menjalankan timer latihan dan istirahat secara presisi |
| Riwayat | Daftar sesi selesai dan ringkasan konsistensi | Meninjau sesi yang telah diselesaikan secara lokal |
| Tips | Artikel ringkas terkait latihan dan pemulihan | Membaca panduan praktis untuk program bulking |
| Panduan | Pengantar cara memakai aplikasi dan penjelasan program | Memahami alur dan aturan penggunaan BulkTimer |
| Kebijakan dan Persyaratan | Teks kebijakan privasi serta ketentuan penggunaan | Menyediakan informasi legal aplikasi |

## Alur Pengguna Utama

Pengguna membuka **Beranda**, membaca latihan untuk hari ini, lalu memilih kartu latihan. Pada **Detail Hari**, pengguna menekan tombol **Mulai Sesi** di area bawah. Aplikasi membuka **Sesi Aktif**, menjalankan hitung mundur set atau istirahat, dan pengguna dapat menjeda, melanjutkan, atau mengakhiri sesi. Saat sesi selesai, aplikasi menyimpan ringkasan secara lokal dan mengarahkan pengguna ke **Riwayat** atau kembali ke Beranda.

Pengguna yang baru pertama kali memakai aplikasi dapat membuka tab **Panduan**, kemudian kembali ke Beranda untuk memilih hari latihan. Pengguna juga dapat membaca tab **Tips** tanpa mengganggu timer aktif.

## Tata Letak dan Interaksi

Beranda menggunakan daftar kartu vertikal dengan jarak sentuh minimal 44 pt. Informasi terpenting diletakkan di setengah atas layar, sedangkan tindakan utama selalu berada dalam jangkauan ibu jari di bawah. Layar sesi aktif mengutamakan angka timer di tengah, dilengkapi tombol lingkaran besar untuk mulai/jeda dan tombol teks sekunder untuk mengakhiri sesi. Tab bar bawah menyediakan akses stabil ke Beranda, Riwayat, dan Tips; tautan Panduan serta legal diletakkan pada bagian bawah layar Tips agar navigasi utama tetap ringkas.

## Warna dan Tipografi

| Peran | Warna | Alasan |
|---|---|---|
| Aksen utama | `#16A34A` | Hijau latihan yang memberi asosiasi progres dan energi tanpa terasa agresif |
| Latar | `#F8FAFC` | Putih kebiruan yang ringan untuk keterbacaan di lingkungan gym |
| Permukaan kartu | `#FFFFFF` | Memberi pemisahan lembut antarkonten |
| Teks utama | `#0F172A` | Kontras tinggi dan mudah dibaca |
| Teks sekunder | `#64748B` | Informasi pendukung tanpa bersaing dengan konten utama |
| Keberhasilan | `#15803D` | Konfirmasi set atau sesi selesai |
| Peringatan | `#D97706` | Menandai sesi belum selesai atau pengingat |
| Kesalahan | `#DC2626` | Tindakan destruktif seperti mengakhiri sesi |

Tipografi menggunakan ukuran 34 pt untuk penghitung waktu, 28 pt untuk judul layar, 17 pt untuk judul kartu, dan 15–16 pt untuk isi. Semua kontrol mengutamakan label yang jelas serta umpan balik tekan yang halus.
