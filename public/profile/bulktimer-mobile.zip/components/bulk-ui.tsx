import type { ReactNode } from "react";
import { Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from "react-native";

export const palette = {
  background: "#24262D",
  surface: "#30323A",
  surfaceMuted: "#3A3D46",
  text: "#F9FAFB",
  muted: "#D5D7E0",
  border: "#555966",
  primary: "#FF8A31",
  primaryDeep: "#DF4E30",
  primaryDark: "#40180F",
  primarySoft: "#68412D",
  warning: "#F9BC5C",
  warningSoft: "#4B3821",
  danger: "#F45B57",
  dangerSoft: "#4E272A",
  success: "#71E5A9",
  successSoft: "#214737",
};

export function Card({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function SectionTitle({ children }: { children: string }) {
  return <Text style={styles.sectionTitle}>{children}</Text>;
}

export function PrimaryButton({
  label,
  onPress,
  disabled = false,
  tone = "primary",
  leading,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  tone?: "primary" | "secondary" | "danger";
  leading?: ReactNode;
}) {
  const buttonStyle = tone === "primary" ? styles.primaryButton : tone === "danger" ? styles.dangerButton : styles.secondaryButton;
  const textStyle = tone === "secondary" ? styles.secondaryButtonText : styles.primaryButtonText;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [buttonStyle, pressed && !disabled && styles.pressed, disabled && styles.disabled]}
    >
      {leading}
      <Text style={textStyle}>{label}</Text>
    </Pressable>
  );
}

export function Tag({ label, tone = "green" }: { label: string; tone?: "green" | "gray" | "amber" | "red" }) {
  const toneStyle = tone === "green" ? styles.tagGreen : tone === "amber" ? styles.tagAmber : tone === "red" ? styles.tagRed : styles.tagGray;
  const textTone = tone === "green" ? styles.tagGreenText : tone === "amber" ? styles.tagAmberText : tone === "red" ? styles.tagRedText : styles.tagGrayText;
  return <View style={[styles.tag, toneStyle]}><Text style={[styles.tagText, textTone]}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  card: { backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, borderRadius: 22, padding: 16 },
  sectionTitle: { color: palette.muted, fontSize: 12, fontWeight: "800", letterSpacing: 1.3, textTransform: "uppercase", marginBottom: 10 },
  primaryButton: { minHeight: 54, borderRadius: 17, backgroundColor: palette.primary, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, paddingHorizontal: 18 },
  dangerButton: { minHeight: 50, borderRadius: 16, backgroundColor: palette.danger, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, paddingHorizontal: 18 },
  secondaryButton: { minHeight: 50, borderRadius: 16, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, paddingHorizontal: 18 },
  primaryButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "800" },
  secondaryButtonText: { color: palette.text, fontSize: 15, fontWeight: "800" },
  pressed: { opacity: 0.88, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.5 },
  tag: { alignSelf: "flex-start", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5 },
  tagText: { fontSize: 12, fontWeight: "800" },
  tagGreen: { backgroundColor: palette.successSoft }, tagGreenText: { color: palette.success },
  tagGray: { backgroundColor: palette.surfaceMuted },   tagGrayText: { color: palette.text },

  tagAmber: { backgroundColor: palette.warningSoft }, tagAmberText: { color: palette.warning },
  tagRed: { backgroundColor: palette.dangerSoft }, tagRedText: { color: palette.danger },
});
