import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo } from "react";
import { StyleSheet, Text, View } from "react-native";
import Svg, { Circle, Line, Path, Rect } from "react-native-svg";

import { palette } from "@/components/bulk-ui";
import type { Exercise } from "@/data/bulk";

type DemoKind = "push" | "pull" | "press" | "curl" | "squat" | "lunge" | "bridge" | "plank" | "twist" | "stretch" | "walk" | "dips" | "facePull" | "lateralRaise" | "calf";

const stroke = "#F9FAFB";
const accent = "#FF8A31";

export function demoKindForExercise(exercise: Exercise): DemoKind {
  const name = exercise.name.toLowerCase();
  if (name.includes("push up")) return "push";
  if (name.includes("pull up")) return "pull";
  if (name.includes("dumbbell row")) return "pull";
  if (name.includes("face pull")) return "facePull";
  if (name.includes("shoulder press")) return "press";
  if (name.includes("lateral raise")) return "lateralRaise";
  if (name.includes("bicep curl")) return "curl";
  if (name.includes("triceps dips")) return "dips";
  if (name.includes("squat")) return "squat";
  if (name.includes("lunge")) return "lunge";
  if (name.includes("bridge") || name.includes("hip thrust")) return "bridge";
  if (name.includes("calf raise")) return "calf";
  if (name.includes("plank")) return "plank";
  if (name.includes("russian twist")) return "twist";
  if (name.includes("stretch") || name.includes("yoga")) return "stretch";
  if (name.includes("jalan")) return "walk";
  return "press";
}

const instructions: Record<DemoKind, string> = {
  push: "Badan lurus, turunkan dada perlahan, lalu dorong kembali.",
  pull: "Tarik siku ke belakang hingga dada mendekati palang atau beban.",
  press: "Dorong beban dari bahu ke atas tanpa mengunci siku.",
  curl: "Tekuk siku, angkat beban dengan lengan tetap dekat tubuh.",
  squat: "Dorong pinggul ke belakang, turunkan badan, lalu berdiri tegap.",
  lunge: "Langkahkan satu kaki, turunkan lutut, lalu kembali ke posisi awal.",
  bridge: "Dorong pinggul ke atas, tahan sejenak, lalu turunkan dengan kontrol.",
  plank: "Jaga tubuh lurus dari kepala hingga tumit dan kencangkan perut.",
  twist: "Putar badan dari sisi ke sisi dengan punggung tetap panjang.",
  stretch: "Lakukan rentang gerak pelan dan bernapas teratur.",
  walk: "Langkah stabil, bahu rileks, dan ayunkan lengan secara natural.",
  dips: "Turunkan tubuh dengan siku mengarah ke belakang, lalu dorong naik.",
  facePull: "Tarik kedua tangan ke arah wajah dengan siku tetap tinggi.",
  lateralRaise: "Angkat lengan ke samping setinggi bahu, lalu turunkan perlahan.",
  calf: "Naikkan tumit hingga bertumpu pada ujung kaki, lalu turunkan perlahan.",
};

function Figure({ kind }: { kind: DemoKind }) {
  if (kind === "push") return <><Circle cx="78" cy="70" r="11" fill={stroke} /><Line x1="93" y1="82" x2="220" y2="103" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="105" y1="85" x2="86" y2="124" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="132" y1="91" x2="120" y2="126" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="218" y1="103" x2="269" y2="124" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="269" y1="124" x2="292" y2="124" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M110 55 Q150 35 195 48" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "pull") return <><Line x1="117" y1="28" x2="243" y2="28" stroke={accent} strokeWidth="7" strokeLinecap="round" /><Circle cx="180" cy="55" r="11" fill={stroke} /><Line x1="180" y1="68" x2="180" y2="119" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="72" x2="147" y2="34" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="72" x2="213" y2="34" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="119" x2="153" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="119" x2="207" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M130 52 L145 37 M230 52 L215 37" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "press") return <><Circle cx="180" cy="48" r="11" fill={stroke} /><Line x1="180" y1="62" x2="180" y2="122" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="78" x2="140" y2="38" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="78" x2="220" y2="38" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Circle cx="136" cy="34" r="6" fill={accent} /><Circle cx="224" cy="34" r="6" fill={accent} /><Line x1="180" y1="122" x2="151" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="209" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M122 25 Q180 5 238 25" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "curl") return <><Circle cx="180" cy="46" r="11" fill={stroke} /><Line x1="180" y1="60" x2="180" y2="119" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="77" x2="149" y2="102" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="149" y1="102" x2="164" y2="74" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="77" x2="211" y2="102" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="211" y1="102" x2="196" y2="74" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Circle cx="164" cy="69" r="6" fill={accent} /><Circle cx="196" cy="69" r="6" fill={accent} /><Line x1="180" y1="119" x2="151" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="119" x2="209" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M132 96 Q145 72 157 62 M228 96 Q215 72 203 62" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "squat") return <><Circle cx="180" cy="42" r="11" fill={stroke} /><Line x1="180" y1="56" x2="157" y2="92" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="157" y1="92" x2="213" y2="106" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="157" y1="92" x2="111" y2="110" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="111" y1="110" x2="91" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="213" y1="106" x2="250" y2="130" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="250" y1="130" x2="274" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M143 122 Q180 145 217 122" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "lunge") return <><Circle cx="180" cy="42" r="11" fill={stroke} /><Line x1="180" y1="56" x2="180" y2="93" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="72" x2="146" y2="101" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="72" x2="214" y2="101" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="93" x2="231" y2="121" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="231" y1="121" x2="271" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="93" x2="148" y2="124" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="148" y1="124" x2="122" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M104 65 L125 65 M110 57 L125 65 L110 73" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></>;
  if (kind === "bridge") return <><Circle cx="75" cy="119" r="11" fill={stroke} /><Line x1="90" y1="123" x2="168" y2="104" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="168" y1="104" x2="221" y2="135" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="221" y1="135" x2="270" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="169" y1="104" x2="134" y2="146" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="134" y1="146" x2="112" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M110 91 Q168 53 226 91" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "plank") return <><Circle cx="77" cy="77" r="11" fill={stroke} /><Line x1="91" y1="84" x2="213" y2="110" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="111" y1="90" x2="93" y2="128" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="213" y1="110" x2="266" y2="137" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="266" y1="137" x2="292" y2="137" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M123 62 L155 62 M205 75 L237 75" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "twist") return <><Circle cx="152" cy="50" r="11" fill={stroke} /><Line x1="152" y1="64" x2="152" y2="101" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="152" y1="77" x2="207" y2="62" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="152" y1="78" x2="105" y2="61" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="152" y1="101" x2="217" y2="132" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="217" y1="132" x2="270" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="152" y1="101" x2="100" y2="135" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="100" y1="135" x2="70" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M92 34 Q180 0 268 34" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "walk") return <><Circle cx="180" cy="44" r="11" fill={stroke} /><Line x1="180" y1="58" x2="180" y2="111" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="74" x2="148" y2="98" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="74" x2="213" y2="93" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="111" x2="144" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="111" x2="220" y2="142" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="220" y1="142" x2="250" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M76 112 L112 112 M93 98 L112 112 L93 126 M260 82 L294 82 M277 68 L294 82 L277 96" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></>;
  if (kind === "dips") return <><Line x1="118" y1="45" x2="118" y2="151" stroke={accent} strokeWidth="8" strokeLinecap="round" /><Line x1="242" y1="45" x2="242" y2="151" stroke={accent} strokeWidth="8" strokeLinecap="round" /><Line x1="107" y1="45" x2="253" y2="45" stroke={accent} strokeWidth="8" strokeLinecap="round" /><Circle cx="180" cy="65" r="11" fill={stroke} /><Line x1="180" y1="79" x2="180" y2="111" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="85" x2="142" y2="88" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="85" x2="218" y2="88" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="111" x2="151" y2="143" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="111" x2="209" y2="143" stroke={stroke} strokeWidth="8" strokeLinecap="round" /></>;
  if (kind === "facePull") return <><Line x1="90" y1="84" x2="140" y2="84" stroke={accent} strokeWidth="5" strokeLinecap="round" /><Circle cx="180" cy="47" r="11" fill={stroke} /><Line x1="180" y1="61" x2="180" y2="122" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="79" x2="145" y2="84" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="145" y1="84" x2="169" y2="57" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="79" x2="215" y2="84" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="215" y1="84" x2="191" y2="57" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="151" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="209" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Path d="M131 52 L155 75 M229 52 L205 75" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
  if (kind === "lateralRaise") return <><Circle cx="180" cy="47" r="11" fill={stroke} /><Line x1="180" y1="61" x2="180" y2="122" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="78" x2="128" y2="65" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="78" x2="232" y2="65" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="128" y1="65" x2="103" y2="51" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="232" y1="65" x2="257" y2="51" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Circle cx="98" cy="48" r="6" fill={accent} /><Circle cx="262" cy="48" r="6" fill={accent} /><Line x1="180" y1="122" x2="151" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="209" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /></>;
  return <><Circle cx="180" cy="47" r="11" fill={stroke} /><Line x1="180" y1="61" x2="180" y2="122" stroke={stroke} strokeWidth="9" strokeLinecap="round" /><Line x1="180" y1="78" x2="146" y2="99" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="78" x2="214" y2="99" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="151" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="180" y1="122" x2="209" y2="151" stroke={stroke} strokeWidth="8" strokeLinecap="round" /><Line x1="151" y1="151" x2="151" y2="137" stroke={accent} strokeWidth="6" strokeLinecap="round" /><Line x1="209" y1="151" x2="209" y2="137" stroke={accent} strokeWidth="6" strokeLinecap="round" /><Path d="M137 125 L137 101 M223 125 L223 101" stroke={accent} strokeWidth="4" strokeLinecap="round" /></>;
}

export function ExerciseDemo({ exercise, compact = false }: { exercise: Exercise; compact?: boolean }) {
  const kind = useMemo(() => demoKindForExercise(exercise), [exercise]);
  return (
    <View style={[styles.frame, compact && styles.compactFrame]}>
      <View style={[styles.imageShell, compact && styles.compactImageShell]}>
        <Svg width="100%" height="100%" viewBox="0 0 360 180" accessibilityLabel={`Ilustrasi contoh ${exercise.name}`}>
          <Rect width="360" height="180" fill={palette.background} />
          <Line x1="18" y1="158" x2="342" y2="158" stroke={palette.border} strokeWidth="2" />
          <Figure kind={kind} />
        </Svg>
        <View style={styles.imageBadge}><MaterialIcons name="visibility" size={14} color={palette.primary} /><Text style={styles.badgeText}>CONTOH GERAKAN</Text></View>
      </View>
      {!compact && <Text style={styles.instruction}>{instructions[kind]}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  frame: { backgroundColor: palette.surfaceMuted, borderColor: palette.border, borderWidth: 1, borderRadius: 22, padding: 12, overflow: "hidden" },
  compactFrame: { padding: 8, borderRadius: 16 },
  imageShell: { height: 205, borderRadius: 15, overflow: "hidden", backgroundColor: palette.background },
  compactImageShell: { height: 116, borderRadius: 11 },
  imageBadge: { position: "absolute", top: 10, left: 10, flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "rgba(36,38,45,0.9)", borderRadius: 99, paddingHorizontal: 8, paddingVertical: 5 },
  badgeText: { color: palette.primary, fontSize: 9, fontWeight: "900", letterSpacing: 0.5 },
  instruction: { color: palette.muted, fontSize: 13, lineHeight: 19, marginTop: 9 },
});
